//Nested Try-Catch

import java.util.Scanner;
public class Nested_Trycatch
{
  public static void main(String[] args) {
    int a, b, div;
    int arr[] = {1, 2, 3, 4, 5};
    try
    {
    try
    {
      Scanner in = new Scanner(System.in);
      System.out.println("Enter dividend: ");
      a = in.nextInt();
      System.out.println("Enter divider: ");
      b = in.nextInt();
      div = a/b;
      System.out.println("Answer: "+div);
    }
    catch(ArithmeticException e)
    {
      System.out.println("Error: Divided by Zero");
    }
    try
    {
      Scanner sc = new Scanner(System.in);
      int n;
      System.out.println("Enter the element upto which array is printed: ");
      n = sc.nextInt();
      for(int i=0; i<n; i++)
      {
        System.out.println("Array: "+arr[i]);
      }
    }
    catch(ArrayIndexOutOfBoundsException e){
      System.out.println("ELement doesn't exist in array");
    }
  }
  catch(Exception e)
  {
    System.out.println("Error Handled");
  }
  }
}
