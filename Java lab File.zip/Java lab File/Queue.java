//Queue

interface pp
{
    void disp();
    void enqueue(int n);
    int dequeue();


}  


class FixedQueue implements pp{
    int front = -1;
    int rear = -1;
    int q[] = new int[5];


    public void disp(){
        System.out.println("\nThe elements in the queue are:");
    if(front==-1)
        System.out.println("\nQueue is Empty");
    else
        for(int i=front;i<=rear;i++)
        {
           
            System.out.println(q[i]);
        }
    }
    public void enqueue(int item){
        if(rear==q.length-1){
            System.out.println("Queue overflowed!!");
            return;
        }else if(front==-1&&rear==-1){
            front=rear=0;
            q[rear]=item;
        }else{
            rear++;
            q[rear]=item;
        }
    }
    public int dequeue(){
        if(front==-1||front>rear)
        {
            System.out.println("Queue underflowed!!");
        }
        else
        {
            q[front] = 0;
            front = front + 1;
        }
        disp();
        return 0;
    }


}


public class Queue{
    public static void main(String[] args)
    {
        FixedQueue obj = new FixedQueue();
        obj.enqueue(1);
        obj.enqueue(2);
        obj.enqueue(3);
        obj.enqueue(4);
        obj.enqueue(5);
        obj.disp();
        System.out.println("After Dequeue: ");
        for(int i=0; i<5; i++)
        {
            obj.dequeue();
        }
    }
}