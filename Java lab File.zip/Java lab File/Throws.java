//Throws

public class Throws{
  public static void main(String[] args) {
    try {
      printValue(0);
    } catch (IllegalArgumentException e) {
      System.out.println("An error occurred: " + e.getMessage());
    }
  }


  public static void printValue(int value) throws IllegalArgumentException {
    if (value == 0) {
      throw new IllegalArgumentException("Value cannot be zero");
    }
    System.out.println(value);
  }
}