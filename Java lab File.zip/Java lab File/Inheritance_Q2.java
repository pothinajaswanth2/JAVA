//Program to perform Inheritance of Classes

import java.util.Scanner;
abstract class Shape {
    int l=0, b=0;
    Shape()
    {
        System.out.print("Enter Length: ");
        Scanner sc = new Scanner(System.in);
        l = sc.nextInt();
        System.out.print("Enter Breadth: ");
        b = sc.nextInt();
    }
    abstract void area();
    abstract void perimeter();
}
class Rectangle extends Shape {
    void area() {
        System.out.println("Area is: "+ l*b);
    }
    void perimeter() {
        System.out.println("Perimeter is: "+ l+b);
    }
}


class Cuboid extends Shape {
    int h;
    Cuboid() {
System.out.print("Enter Height: ");
Scanner c = new Scanner(System.in);
        h = c.nextInt();
    }
    void area() {
        System.out.println("Area is: "+ 2*(l*b + b*h + l*h));
    }
    void perimeter() {
        System.out.println("Perimeter is: "+ 2*(l+b+h));
    }
    void vol() {
        System.out.println("Volume is: "+ l*b*h);
    }
}


public class Inheritance_Q2{
    public static void main(String[] args) {
        Shape s;
        Rectangle r = new Rectangle();
        r.area();
        r.perimeter();
        Cuboid c = new Cuboid();
        c.area();
        c.perimeter();
        c.vol();
    }
}