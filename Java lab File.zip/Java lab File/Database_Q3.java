//Student Database Program(in Java)

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


class Student implements Comparable<Student> {
  String name;
  int rollNumber;
  double average;


  public Student(String name, int rollNumber, double average) {
    this.name = name;
    this.rollNumber = rollNumber;
    this.average = average;
  }


  public int compareTo(Student student) {
    if (this.average == student.average) {
      return 0;
    } else if (this.average > student.average) {
      return 1;
    } else {
      return -1;
    }
  }
}


public class Database_Q3 {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    ArrayList<Student> students = new ArrayList<Student>();
    int n;
    System.out.print("Enter the number of students: ");
    n = scan.nextInt();
    scan.nextLine();


    for (int i = 0; i < n; i++) {
      System.out.print("Enter the name of student " + (i + 1) + ": ");
      String name = scan.nextLine();
      System.out.print("Enter the roll number of student " + (i + 1) + ": ");
      int rollNumber = scan.nextInt();
      System.out.print("Enter the marks in physics of student " + (i + 1) + ": ");
      double physics = scan.nextDouble();
      System.out.print("Enter the marks in chemistry of student " + (i + 1) + ": ");
      double chemistry = scan.nextDouble();
      System.out.print("Enter the marks in maths of student " + (i + 1) + ": ");
      double maths = scan.nextDouble();
      scan.nextLine();


      double average = (physics + chemistry + maths) / 3;
      students.add(new Student(name, rollNumber, average));
    }


    Collections.sort(students);
    System.out.println("Name\tRoll Number\tAverage");
    for (int i = 0; i < n; i++) {
      System.out.println(students.get(i).name + "\t" + students.get(i).rollNumber + "\t\t" + students.get(i).average);
    }
  }
}