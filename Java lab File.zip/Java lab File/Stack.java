//Stacks

interface hehe{
  void push(int x);
  void display();
  void pop();
}
class FixedStack implements hehe{
  int top = -1;
  int stack[] = new int[5];
  public void push(int n){
      if(top == stack.length-1){
          System.out.println("Overflow :(");}
      else{    
      top = top+1;
          stack[top] = n;
        }
      }
  public void pop(){
      if(top == -1){
          System.out.println("Underflow T-T");
        }
      else{
          top = top - 1;
        }
      display();
    }
  public void display(){
      if(top == -1){
          System.out.println("Underflow T-T");
          return;
        }
      else{
          System.out.println("Elements in Stack are: ");
          for(int i = top; i>=0; i--){
              System.out.println(stack[i]);
            }
          }
        }
      }
public class Stack{
  public static void main(String[] args) {
      FixedStack s = new FixedStack();
      s.push(1);
      s.push(2);
      s.push(3);
      s.push(4);
      s.push(5);
      s.display();
      for(int i = 0; i<=4; i++){s.pop();}
    }
  }