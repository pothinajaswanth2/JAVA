import java.util.Scanner;

// import java.util.Scanner;
// public class OOPS
// {
//     public static void main(String[] args) { 
//        int ans = sum2();
//        System.out.println(ans);
//     }
//     static int sum2(){
//         Scanner in = new Scanner(System.in);
//             System.out.println("Enter No 1:");
//             int num1 = in.nextInt();
//             System.out.println("Enter no 2:");
//             int num2 = in.nextInt();
//             int sum = num1 + num2;
//             return sum;
        
//     }
   
// }
// public class OOPS{
//     public static void main(String[] args) {
//         String message = greet();
//         System.out.println(message);
//     } 
//     static String greet(){
//         String greeting = "How are you bro!!";
//         return greeting;
//     }
// }



// public class OOPS{
//     public static void main(String[] args) {
//         Scanner in = new Scanner (System.in);
//         System.out.println("enter your name:");
//         String name = in.next();
//         String personalised= mygreet(name);
//         System.out.println(personalised);
//         }
//         static String mygreet(String name){
//             String message = "Hello "+ name;
//             return message;
//         }
// }


