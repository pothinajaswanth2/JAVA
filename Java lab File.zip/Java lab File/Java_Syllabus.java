import java.io.BufferedReader;
import java.io.InputStreamReader;


class Java_Syllabus{
    public static void main(String[] args) {

        BufferedReader redr = new BufferedReader(new InputStreamReader(System.in));
        String name;
        try{
            System.out.println("Enter your Surname:");
            name = redr.readLine();
            System.out.println("Name is "+name+" Dobriyal");
        }
        catch (Exception e) {

        }
    }
}