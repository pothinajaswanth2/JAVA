//public class Basic{
    // public static void main(String[] args){
    //     int[] arr = new int[2];
    //     arr[0] = 10;
    //     arr[1] = 20;
    //     for(int i = 0;i < arr.length; i++)
    //     System.out.println(arr[i]);
    //  }
// }
//2D Arrays
//  public class Basic{
//     public static void main(String[] args) {
        
//         int arr2 [] [] = {{2,5,7},{3,5,6},{4,5,3}};
//     }
//      
//         for(int i=0;i<3;i++){
//             for(int j=0;j<3; j++)
//             System.out.print(arr2[i][j]+ "  ");
//           
//             System.out.println();
//          
//         }

//     }

// }
// import java.util.Arrays;
// class Basic{
//     public static void main(String[] args) {
//         int intArr[] = {10,20,30,22,54};
//         System.out.println("Inter Array as List:"+ Arrays.asList(intArr));
//     }
// }
// Binary search using array
// import java.util.Arrays;
// public class Basic{
//     public static void main(String[] args) {
//         int Arr[] = {10,43,43,43,43,50};
//         Arrays.sort(Arr);
//         int intkey = 43;
//         System.out.println(intkey+ " found at index = "+ Arrays.binarySearch(Arr,1,6,intkey));

//     }
// }


//Multidimessional arrays 
// import java.util.Scanner;
// public class Basic {
// 	public static void main(String[] args)
// 	{
// 		Scanner scan = new Scanner(System.in);

// 		System.out.print("Enter number of rows: ");
// 		int rows = scan.nextInt();

// 		System.out.print("Enter number of columns: ");
// 		int columns = scan.nextInt();

// 		int[][] multidimensionalArray= new int[rows][columns];

// 		// Now you can use the array like a regular
// 		// 2-dimensional array
// 		for (int i = 0; i < rows; i++) {
// 			for (int j = 0; j < columns; j++) {
// 				multidimensionalArray[i][j]= (i + 1) * (j + 1);
// 			}
// 		}
// 		for (int i = 0; i < rows; i++) {
// 			for (int j = 0; j < columns; j++) {
// 				System.out.print(multidimensionalArray[i][j]+ " ");
// 			}

// 			System.out.println();
// 		}
// 		scan.close();
// 	}
// }

// Method calling 
// class Basic{
// 	int sum=0;
// 	public int addtwoint(int a, int b)
// 	{
// 		sum = a+b;
// 		return sum;
// 	}
// }//Method here is called in the class operation
// class operation{
// 	public static void main(String[] args) {
// 		Basic add = new Basic();
// 		int s = add.addtwoint(1,2);
// 		System.out.println("Sum of two values:" + s);
// 	}
// }
// // Showing unsuppotance of Multiple Inheritance
// import java.io.*;
// class parent1{
// 	void fun(){
// 		System.out.println("Parent1");
// 	}
// }
// class parent2{
// 	void fun(){
// 		System.out.println("Parent2");
// 	}
// }
// class Test extends parent1,parent2 {
// 	public static void main(String[] args) {
// 		Test t = w Test();
// 		t.fun();
// 	}
// }//Therefore an error is thrown at the execution

//Implementation of Interfaces and how a class accesses them
// import java.io.*;
// interface int1{
// 	void m1();
// }
// interface int2{
// 	void m2();
// }
// class sample implements int1,int2{
//      @Override
// 	public void m1()
// 	{
// 		System.out.println("Welcome to method one boisss:");
// 	}
// 	@Override
// 	public void m2()
// 		{
// 			System.out.println("Welcome to the second method bois");
// 		}
// 	}
// 	class Sus
// 	{
// 		public static void main(String[] args) {
// 			sample ob1=  new sample();
// 			ob1.m1();
// 			ob1.m2();
// 	}
// }

//Concept of Association is being impelemented //#hash set has to be lernt in order to understand this
// import java.io.*;
// import java.util.*;
// class Bank{
// 	private String name;
// 	private Set<Employee> employees;
// 	Bank(String name)
// 	{
// 		this.name = name;
// 	}
// 	public String getBankName()
// 	{
// 		return this.name;
// 	}
// 	public static void main(String[] args) {
// 		this.employee = employees;
// 	}
// 	public Set<Employee>
//     getEmployees(Set<Employee> employees)
//     {
//         return this.employees;
    
// }
// }
// class Employee {
//     // Attributes of employee
//     private String name;
//     // Employee name
//     Employee(String name)
//     {
//         // This keyword refers to current instance itself
//         this.name = name;
//     }
 
//     // Method of Employee class
//     public String getEmployeeName()
//     {
//         // returning the name of employee
//         return this.name;
//     }
// }
 
// class GFG {
 
//     // Main driver method
//     public static void main(String[] args)
//     {
 
//         // Creating objects of bank and Employee class
//         Bank bank = new Bank("ICICI");
//         Employee emp = new Employee("Ridhi");
 
//         Set<Employee> employees = new HashSet<>();
//         employees.add(emp);
 
//         bank.setEmployees(employees);
 
//         System.out.println(emp.getEmployeeName()
//                            + " belongs to bank "
//                            + bank.getBankName());
//     }
// }


//Abstract keyword impelementation
// abstract class gfg{
//     abstract void intinfo();
// }
// class employee extends gfg {
//     void intinfo(){
//         String name = "Sushanth";
//         int age = 19;
//         float salary = 9834233.2F;

//         System.out.println(name);
//         System.out.println(age);
//         System.out.println(salary);
//     }
// }
// class base {
//     public static void main(String[] args) {
//         gfg s = new employee();
//         s.intinfo();
//     }
// }

//Constructors
// class MyMainEmployee{
//     private int id;
//     private string name;
// }
// public MyMinEmployee(){
//     id = 45; 
// }
// import java.awt.Frame;
// public class Basic{
//    public Basic()
//    {
//     Frame fm = new Frame();
//     fm.setVisible(true);
//     fm.setSize(500,500);
//     fm.setTitle("Sushanth");
//    }
//    public static void main(String[] args) {
//     new Basic();
//    }
// }
// public class Basic {

//     public static void main(String[] args) {
//       int row = 5;
  
//       for (int i = 1; i <= row; ++i) {
//         for (int j = 1; j <= i; ++j) {
//           System.out.print("* "+j);
//         }
//         System.out.println();
//       }
//     }
//   }
// class Pattern {
// static void display(int n)
// {
// int i, j, k;
// for (i = 1; i <= n; i++) {
// for (j = 1, k = i; j <= i; j++, k++) {
// if (k % 2 == 0) {
// System.out.print(j);
// }
// else {
// System.out.print("*");
//   }
// }
// System.out.print("\n");
//   }
// }
// public static void main(String[] args){
//     int n = 5;
//     display(n);
// }
// }


// import java.awt.*;
// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;

// public class Basic extends Frame implements ActionListener {
//     private TextField display;
//     private Button[] buttons;
//     private String[] buttonLabels = {
//             "7", "8", "9", "/",
//             "4", "5", "6", "*",
//             "1", "2", "3", "-",
//             "0", ".", "=", "+"
//     };

//     private StringBuilder input;
//     private double num1, num2;
//     private char operator;

//     public Basic() {
//         input = new StringBuilder();

//         display = new TextField(20);
//         display.setEditable(false);

//         buttons = new Button[buttonLabels.length];

//         Panel buttonPanel = new Panel();
//         buttonPanel.setLayout(new GridLayout(4, 4));

//         for (int i = 0; i < buttonLabels.length; i++) {
//             buttons[i] = new Button(buttonLabels[i]);
//             buttons[i].addActionListener(this);
//             buttonPanel.add(buttons[i]);
//         }

//         add(display, BorderLayout.NORTH);
//         add(buttonPanel, BorderLayout.CENTER);

//         setTitle("Calculator");
//         setSize(300, 300);
//         setVisible(true);
//     }

//     public void actionPerformed(ActionEvent e) {
//         String command = e.getActionCommand();

//         switch (command) {
//             case "0":
//             case "1":
//             case "2":
//             case "3":
//             case "4":
//             case "5":
//             case "6":
//             case "7":
//             case "8":
//             case "9":
//             case ".":
//                 input.append(command);
//                 display.setText(input.toString());
//                 break;

//             case "+":
//             case "-":
//             case "*":
//             case "/":
//                 operator = command.charAt(0);
//                 num1 = Double.parseDouble(input.toString());
//                 input.setLength(0);
//                 break;

//             case "=":
//                 num2 = Double.parseDouble(input.toString());
//                 double result = calculate(num1, num2, operator);
//                 display.setText(String.valueOf(result));
//                 input.setLength(0);
//                 input.append(result);
//                 break;
//         }
//     }

//     private double calculate(double num1, double num2, char operator) {
//         switch (operator) {
//             case '+':
//                 return num1 + num2;
//             case '-':
//                 return num1 - num2;
//             case '*':
//                 return num1 * num2;
//             case '/':
//                 if (num2 != 0)
//                     return num1 / num2;
//                 else
//                     return 0;
//             default:
//                 return 0;
//         }
//     }

//     public static void main(String[] args) {
//         new Basic();
//     }
// }
// 
//smiley in awt
// import java.awt.*;

// public class Basic extends Frame {
//     public Basic() {
//         setSize(300, 300);
//         setTitle("Smiley Face");
//         setVisible(true);
//     }

//     public void paint(Graphics g) {
//         // Draw face
//         g.setColor(Color.YELLOW);
//         g.fillOval(50, 50, 200, 200);

//         // Draw eyes
//         g.setColor(Color.BLACK);
//         g.fillRect(90, 100, 40, 40);
//         g.fillOval(170, 100, 40, 40);

//         // Draw mouth
//         g.setColor(Color.BLACK);
//         g.drawArc(100, 120, 100, 80, 180, 180);
//     }


//     public static void main(String[] args) {
//         new Basic();
//     }
// }
// import java.awt.*;
// public class Basic extends Frame {
//     public Basic(){
//         setSize(300,300);
//         setTitle("Simely Face");
//         setVisible(true);
//     }
//     public void paint(Graphics g){
//         g.setColor(Color.yellow);
//         g.fillOval(50,60,220,220);
//         g.setColor(Color.BLACK);
//         g.fillOval(90,100, 40,40);
//         g.fillOval(180,100, 40,40);
//         g.setColor(Color.BLACK);
//         g.fillArc(100, 120, 100,80, 180, 180);

//     }
//     public static void main(String[] args) {
//         new Basic();
//     }
// }
// class Rectangle {
//     protected double length;
//     protected double breadth;

//     public Rectangle(double length, double breadth) {
//         this.length = length;
//         this.breadth = breadth;
//     }

//     public void calculateArea() {
//         double area = length * breadth;
//         System.out.println("Rectangle Area: " + area);
//     }

//     public void calculatePerimeter() {
//         double perimeter = 2 * (length + breadth);
//         System.out.println("Rectangle Perimeter: " + perimeter);
//     }
// }

// class Square extends Rectangle {
//     public Square(double side) {
//         super(side, side);
//     }
// }


// public class Basic {
//     public static void main(String[] args) {
//         Rectangle rectangle = new Rectangle(4, 5);
//         rectangle.calculateArea();
//         rectangle.calculatePerimeter();

//         Square square = new Square(3);
//         square.calculateArea();
//         square.calculatePerimeter();
//     }
// }
// import java.awt.*;
// import java.awt.event.*;

// public class Basic extends java.applet.Applet implements MouseListener, MouseMotionListener {
//     private int mouseX;
//     private int mouseY;

//     public void init() {
//         addMouseListener(this);
//         addMouseMotionListener(this);
//     }

//     public void paint(Graphics g) {
//         g.drawString("Mouse Position: " + mouseX + ", " + mouseY, 10, 20);
//     }

//     public void mouseEntered(MouseEvent e) {}

//     public void mouseExited(MouseEvent e) {}

//     public void mouseClicked(MouseEvent e) {}

//     public void mousePressed(MouseEvent e) {}

//     public void mouseReleased(MouseEvent e) {}

//     public void mouseMoved(MouseEvent e) {
//         mouseX = e.getX();
//         mouseY = e.getY();
//         repaint();
//     }

//     public void mouseDragged(MouseEvent e) {}
// }
// import java.awt.*;
// import java.awt.event.*;
 
// class Calculator implements ActionListener
// {
// //Declaring Objects
// Frame f=new Frame();
// Label l1=new Label("First Number");
// Label l2=new Label("Second Number");
// Label l3=new Label("Result");
// TextField t1=new TextField();
// TextField t2=new TextField();
// TextField t3=new TextField();
// Button b1=new Button("Add");
// Button b2=new Button("Sub");
// Button b3=new Button("Mul");
// Button b4=new Button("Div");
// Button b5=new Button("Cancel");
// Calculator()
// {
// //Giving Coordinates
// l1.setBounds(50,100,100,20);
// l2.setBounds(50,140,100,20);
// l3.setBounds(50,180,100,20);
// t1.setBounds(200,100,100,20);
// t2.setBounds(200,140,100,20);
// t3.setBounds(200,180,100,20);
// b1.setBounds(50,250,50,20);
// b2.setBounds(110,250,50,20);
// b3.setBounds(170,250,50,20);
// b4.setBounds(230,250,50,20);
// b5.setBounds(290,250,50,20);
// //Adding components to the frame
// f.add(l1);
// f.add(l2);
// f.add(l3);
// f.add(t1);
// f.add(t2);
// f.add(t3);
// f.add(b1);
// f.add(b2);
// f.add(b3);
// f.add(b4);
// f.add(b5);
// b1.addActionListener(this);
// b2.addActionListener(this);
// b3.addActionListener(this);
// b4.addActionListener(this);
// b5.addActionListener(this);
// f.setLayout(null);
// f.setVisible(true);
// f.setSize(400,350);
// }
// public void actionPerformed(ActionEvent e)
// {
// int n1=Integer.parseInt(t1.getText());
// int n2=Integer.parseInt(t2.getText());
// if(e.getSource()==b1)
// {
// t3.setText(String.valueOf(n1+n2));
// }
// if(e.getSource()==b2)
// {
// t3.setText(String.valueOf(n1-n2));
// }
// if(e.getSource()==b3)
// {
// t3.setText(String.valueOf(n1*n2));
// }
// if(e.getSource()==b4)
// {
// t3.setText(String.valueOf(n1/n2));
// }
// if(e.getSource()==b5)
// {
// System.exit(0);
// }
// }
// public static void main(String...s)
// {
// new Calculator();
// }
// }