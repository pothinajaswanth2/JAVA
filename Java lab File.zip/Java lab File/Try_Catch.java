//Try-Catch

import java.util.Scanner;
public class Try_Catch
{
  public static void main(String[] args) {
    int a = 5, b = 5, c = 10, d;
    int arr[] = {1, 2, 3, 4, 5};
  try {
     d = c/(a-b);
     System.out.println("Result: "+d);  
  } catch (ArithmeticException e) {
     System.out.println("Error: Divided by zero");
  }
  try {
      int n;
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter element to be printed: ");
      n = sc.nextInt();
      System.out.print("Element is: "+arr[n]);
    }
  catch(ArrayIndexOutOfBoundsException f){
    System.out.println("Element entered is doesn't exist");
  }
}
}
